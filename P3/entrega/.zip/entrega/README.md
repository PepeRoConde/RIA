# Instrucciones

    python -m venv venvRomeroFerreiro
    source venvRomeroFerreiro/bin/activate
    pip install -r requirements.txt

    python codigo/main.py

Si surge un error relacionado con la cámara, ir al `configs/config.yaml` y cambiar ``src_webcam`` a `0`




 
